
jQuery(document).ready(function ($) {

	var tweenAnimIn = new TimelineMax ()
	
		tweenAnimIn 
		.set("h1", {autoAlpha:0})
		.from(".body", 5, {x:-900, autoAlpha: 0, ease:Power2.easeOut})
	


var controller = new ScrollMagic.controller(); 

var scrollOutAnim = new TimelineMax()
	.add([
		TweenMax.to(".body", 1, {y:300, autoAlpha:0})
		
	]); 
	
//build Scene 
var scrollScene = new ScrollMagic.Scene({	
	triggerElement: '#food-truck-trigger', 
	triggerHook:0, 
	duration:"100%"})
	
	.setTween(scrollOutAnim)
	.setPin(".pin-truck")
	.addTo(controller); 
	

}); 


