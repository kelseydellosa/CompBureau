jQuery(document).ready(function($) {

    var controller = new ScrollMagic.Controller();

    // define movement of panels
    var wipeAnimation = new TimelineMax()
    // animate to second panel
    .to("#slideContainer", 0.5, {
        z: -55
    }) // move back in 3D space
    .to("#slideContainer", 1, {
        x: "-25%"
    }) // move in to first panel
    .to("#slideContainer", 0.5, {
        z: 0
    }) // move 

    new ScrollMagic.Scene({
        triggerElement: "menu.html",
        triggerHook: "onLeave",
        duration: "500%"
    })
        .setPin("#pinContainer")
        .setTween(wipeAnimation)
        .addIndicators() // add ind(requires plugin)
    .addTo(controller);

// build scene
new ScrollMagic.Scene({
    triggerElement: "#trigger1",
    triggerHook: 0.9, // show, when scrolled 10% into view
    duration: "80%", // hide 10% before exiting view (80% + 10% from bottom)
    offset: 50 // move trigger to center of element
})
    .setClassToggle("#reveal1", "visible") // add class to reveal
.addIndicators() // add indicators (requires plugin)
.addTo(controller);

	});


var player;
function onYouTubeIframeAPIReady() {
  player = new YT.Player('player', {
    height: '430',
    width: '700',
    videoId: 'cSTsf_Y7sds'
  });
}

$(document).on('mouseover', '#player', function() {
  player.playVideo();
});
$(document).on('mouseout', '#player', function() {
  player.pauseVideo();
});

$(".arrow_menu").on("mouseenter", function() {
  var duration = 1;
  TweenMax.to(this, duration / 4, {x:5,y:-50, ease:Power2.easeOut});
  TweenMax.to(this, duration / 2, {y:0, ease:Bounce.easeOut, delay:duration / 3});
});




//jQuery(document).ready(function ($) {
//    
//   var tweenAnimIn = new TimelineMax ()
//   
//        tweenAnimIn 
//        .set("h1", {autoAlpha:0})
////        .from(".sleigh-side-1", 1, { x:-200, autoAlpha: 0, ease:Power2.easeOut}, )
////	       .from(".sleigh-side-1", 1, {x:0, autoAlpha: 1})
//
//
//
//var controller = new ScrollMagic.Controller();
//
//var scrollOutAnim = new TimelineMax()
//    .add([
//        TweenMax.to(".sleigh-side-1", 10, {x:2500, autoAlpha: 1}),
//        TweenMax.to("h1", 1, {autoAlpha: 1}),
//    
//    ]);
//
//
////build Scene 
// var scrollScene = new ScrollMagic.Scene({
//     triggerElement: '#big-sleigh-trigger',
//     triggerHook:0,
//     duration: "100%"})
//     
//    .setTween(scrollOutAnim)
//    .setPin(".pin-sleigh")
//    .addTo(controller);
//
//
//			var controller = new ScrollMagic.Controller();
//
//		// define movement of panels
//		var wipeAnimation = new TimelineMax()
//			.fromTo("section.panel.turqoise", 1, {x: "-100%"}, {x: "0%", ease: Linear.easeNone})  // in from left
//			.fromTo("section.panel.green",    1, {x:  "100%"}, {x: "0%", ease: Linear.easeNone})  // in from right
//			.fromTo("section.panel.bordeaux", 1, {y: "-100%"}, {y: "0%", ease: Linear.easeNone}); // in from top
//
//		// create scene to pin and link animation
//		new ScrollMagic.Scene({
//				triggerElement: "#pinContainer",
//				triggerHook: "onLeave",
//				duration: "300%"
//			})
//			.setPin("#pinContainer")
//			.setTween(wipeAnimation)
//			.addIndicators() // add indicators (requires plugin)
//			.addTo(controller);
//
//});